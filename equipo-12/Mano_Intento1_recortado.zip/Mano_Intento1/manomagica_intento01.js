var length = data.length;

// escribe tu trabajo aqui
// -----------------------

for(i=0; i<7200;i++){
	 ball=data[i]
    create(ball.x, ball.y, ball.color)
    }

    