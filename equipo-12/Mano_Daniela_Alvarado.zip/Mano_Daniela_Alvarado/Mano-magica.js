var length = data.length;

// escribe tu trabajo aqui
// -----------------------

for(i=0; i<202496;i++){
	 ball=data[i]
    create(ball.x, ball.y, ball.color)
    }